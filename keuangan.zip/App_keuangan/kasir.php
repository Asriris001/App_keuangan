<?php
// kasir.php
$pageTitle = 'Kasir Penjualan';
$headerTitle = 'Kasir / Input Penjualan';
$headerSubtitle = 'Catat pemasukan dan penjualan baru dengan cepat dan rapi';

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/helpers.php';

// Handle POST Transaksi Baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'simpan_transaksi') {
    $nomor_transaksi = trim($_POST['nomor_transaksi'] ?? generate_nomor_transaksi($pdo));
    $tanggal = $_POST['tanggal'] ?? date('Y-m-d');
    $waktu = date('H:i:s');
    $nama_pelanggan = trim($_POST['nama_pelanggan'] ?: 'Pelanggan Umum');
    $metode_pembayaran = $_POST['metode_pembayaran'] ?? 'Tunai';
    $status_pembayaran = $_POST['status_pembayaran'] ?? 'Lunas';
    $diskon = (float)str_replace(['.', ','], '', $_POST['diskon'] ?? '0');
    $bayar = (float)str_replace(['.', ','], '', $_POST['bayar'] ?? '0');
    $catatan = trim($_POST['catatan'] ?? '');
    $items = json_decode($_POST['items_json'] ?? '[]', true);

    if (empty($items) || !is_array($items)) {
        set_flash('error', 'Gagal Menyimpan!', 'Keranjang belanja masih kosong. Tambahkan minimal 1 item.');
        header('Location: kasir.php');
        exit;
    }

    try {
        $pdo->beginTransaction();

        $total_penjualan = 0;
        $total_modal = 0;

        foreach ($items as $it) {
            $sub = (float)$it['harga_satuan'] * (int)$it['qty'];
            $total_penjualan += $sub;
            $total_modal += ((float)($it['harga_modal'] ?? 0) * (int)$it['qty']);
        }

        $total_akhir = max(0, $total_penjualan - $diskon);

        // Jika metode bukan tunai atau bayar diisi 0, anggap bayar pas
        if ($metode_pembayaran !== 'Tunai' && $bayar == 0) {
            $bayar = $total_akhir;
        }

        $kembalian = max(0, $bayar - $total_akhir);

        // 1. Simpan Transaksi Header
        $kasirNama = $_SESSION['user']['nama_lengkap'] ?? 'Kasir';
        $stmtTrx = $pdo->prepare("
            INSERT INTO `transaksi` 
            (nomor_transaksi, tanggal, waktu, nama_pelanggan, kasir_nama, total_modal, total_penjualan, diskon, total_akhir, bayar, kembalian, metode_pembayaran, status_pembayaran, catatan) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmtTrx->execute([
            $nomor_transaksi, $tanggal, $waktu, $nama_pelanggan, $kasirNama, $total_modal, $total_penjualan, $diskon, $total_akhir, $bayar, $kembalian, $metode_pembayaran, $status_pembayaran, $catatan
        ]);
        $transaksiId = $pdo->lastInsertId();

        // 2. Simpan Detail Transaksi & Kurangi Stok Produk
        $stmtDetail = $pdo->prepare("
            INSERT INTO `transaksi_detail` 
            (transaksi_id, produk_id, nama_item, harga_modal, harga_satuan, qty, subtotal) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmtKurangiStok = $pdo->prepare("UPDATE `produk` SET stok = GREATEST(0, stok - ?) WHERE id = ?");

        foreach ($items as $it) {
            $pId = !empty($it['produk_id']) ? (int)$it['produk_id'] : null;
            $namaItem = trim($it['nama_item']);
            $hModal = (float)($it['harga_modal'] ?? 0);
            $hSatuan = (float)$it['harga_satuan'];
            $qty = (int)$it['qty'];
            $sub = $hSatuan * $qty;

            $stmtDetail->execute([
                $transaksiId, $pId, $namaItem, $hModal, $hSatuan, $qty, $sub
            ]);

            if ($pId) {
                $stmtKurangiStok->execute([$qty, $pId]);
            }
        }

        $pdo->commit();

        set_flash('success', 'Berhasil!', "Transaksi $nomor_transaksi berhasil disimpan.");

        // Jika tombol cetak struk ditekan
        if (isset($_POST['print_receipt']) && $_POST['print_receipt'] === '1') {
            header("Location: cetak-struk.php?id=$transaksiId&auto=1");
            exit;
        }

        header('Location: kasir.php');
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        set_flash('error', 'Terjadi Kesalahan!', $e->getMessage());
        header('Location: kasir.php');
        exit;
    }
}

// Ambil daftar kategori produk untuk filter
$kategoriList = $pdo->query("SELECT * FROM `kategori` WHERE tipe = 'pemasukan' ORDER BY nama ASC")->fetchAll();

// Ambil daftar produk aktif
$produkList = $pdo->query("
    SELECT p.*, k.nama as nama_kategori 
    FROM `produk` p 
    LEFT JOIN `kategori` k ON p.kategori_id = k.id 
    WHERE p.status = 'aktif' 
    ORDER BY p.nama_produk ASC
")->fetchAll();

$nomorAuto = generate_nomor_transaksi($pdo);

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="flex-1 flex flex-col min-w-0 overflow-hidden">
    <?php require_once __DIR__ . '/includes/topbar.php'; ?>

    <!-- Main Content Area: Split POS Screen (Left: Catalog, Right: Cart) -->
    <main class="flex-1 overflow-y-auto lg:overflow-hidden p-4 md:p-6">
        <div class="h-full flex flex-col lg:flex-row gap-6">

            <!-- LEFT: Produk & Item Kustom (60%) -->
            <div class="w-full lg:w-7/12 flex flex-col bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden h-[750px] lg:h-full">
                
                <!-- Tab Pilihan: Katalog Produk vs Item Bebas -->
                <div class="p-4 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50/50">
                    <div class="flex items-center gap-2">
                        <button type="button" id="tabKatalogBtn" class="px-4 py-2 rounded-xl text-xs font-bold transition-all bg-emerald-600 text-white shadow-sm">
                            <i class="fa-solid fa-boxes-stacked mr-1.5"></i> Produk
                        </button>
                        <button type="button" id="tabCustomBtn" class="px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-600 hover:bg-slate-200/70">
                            <i class="fa-solid fa-pen-to-square mr-1.5"></i> Tambah
                        </button>
                    </div>

                    <div class="text-xs text-slate-500 hidden sm:block">
                        Total: <span class="font-bold text-slate-700"><?= count($produkList) ?></span> Produk
                    </div>
                </div>

                <!-- VIEW 1: KATALOG PRODUK -->
                <div id="viewKatalog" class="flex-1 flex flex-col overflow-hidden p-4">
                    <!-- Search & Category Filters -->
                    <div class="space-y-3 mb-4">
                        <div class="relative">
                            <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
                            <input type="text" id="searchProduct" placeholder="Cari nama produk atau kode (contoh: Kopi, Beras)..." 
                                class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all">
                        </div>

                        <!-- Category Filter Pills -->
                        <div class="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                            <button type="button" class="filter-cat active px-3 py-1.5 rounded-lg font-semibold bg-emerald-100 text-emerald-800 transition-colors whitespace-nowrap" data-cat="all">
                                Semua Kategori
                            </button>
                            <?php foreach ($kategoriList as $kat): ?>
                                <button type="button" class="filter-cat px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:bg-slate-100 transition-colors whitespace-nowrap" data-cat="<?= $kat['id'] ?>">
                                    <?= htmlspecialchars($kat['nama']) ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Product Grid (Scrollable) -->
                    <div class="flex-1 overflow-y-auto pr-1">
                        <div id="productGrid" class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-3 gap-3">
                            <?php foreach ($produkList as $p): ?>
                                <div class="product-card group relative bg-white border border-slate-200 hover:border-emerald-400 rounded-xl p-3 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                                     data-id="<?= $p['id'] ?>"
                                     data-code="<?= htmlspecialchars($p['kode_produk']) ?>"
                                     data-name="<?= htmlspecialchars($p['nama_produk']) ?>"
                                     data-price="<?= $p['harga_jual'] ?>"
                                     data-cost="<?= $p['harga_modal'] ?>"
                                     data-stock="<?= $p['stok'] ?>"
                                     data-cat="<?= $p['kategori_id'] ?>"
                                     onclick="addToCartFromCard(this)">
                                    <div>
                                        <div class="flex items-start justify-between gap-1 mb-1.5">
                                            <span class="text-[10px] font-mono font-medium text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                                <?= htmlspecialchars($p['kode_produk'] ?: 'PRD') ?>
                                            </span>
                                            <span class="text-[10px] font-semibold <?= $p['stok'] > 5 ? 'text-emerald-700 bg-emerald-50' : 'text-amber-700 bg-amber-50' ?> px-1.5 py-0.5 rounded">
                                                Stok: <?= $p['stok'] ?> <?= htmlspecialchars($p['satuan']) ?>
                                            </span>
                                        </div>
                                        <h5 class="text-xs font-semibold text-slate-800 group-hover:text-emerald-700 transition-colors line-clamp-2 leading-snug">
                                            <?= htmlspecialchars($p['nama_produk']) ?>
                                        </h5>
                                    </div>
                                    <div class="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                                        <span class="text-xs font-bold text-emerald-600">
                                            <?= rupiah($p['harga_jual']) ?>
                                        </span>
                                        <div class="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white flex items-center justify-center text-xs transition-colors">
                                            <i class="fa-solid fa-plus"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if (empty($produkList)): ?>
                            <div class="text-center py-12 px-4 text-slate-400 text-xs">
                                <div class="w-14 h-14 rounded-full bg-slate-100 text-slate-300 flex items-center justify-center mx-auto mb-3 text-2xl">
                                    <i class="fa-solid fa-boxes-stacked"></i>
                                </div>
                                <h4 class="font-bold text-slate-700 text-sm mb-1">Katalog Produk Belum Diisi</h4>
                                <p class="text-slate-400 max-w-xs mx-auto mb-4">
                                    Menu/Produk
                                </p>
                                <div class="flex items-center justify-center gap-2">
                                    <a href="produk.php" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-sm transition-all flex items-center gap-1.5">
                                        <i class="fa-solid fa-plus"></i>
                                        <span>Tambah Produk</span>
                                    </a>
                                    <button type="button" onclick="tabCustomBtn.click()" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-all">
                                        Input Manual
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div id="noProductFound" class="hidden text-center py-12 text-slate-400 text-xs">
                            <i class="fa-solid fa-magnifying-glass text-3xl mb-2 text-slate-300"></i>
                            <p>Produk tidak ditemukan sesuai kata kunci.</p>
                        </div>
                    </div>
                </div>

                <!-- VIEW 2: INPUT ITEM MANUAL / BEBAS -->
                <div id="viewCustom" class="hidden flex-1 overflow-y-auto p-5">
                    <div class="max-w-md mx-auto space-y-4">
                        <div class="p-4 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-emerald-800">
                            <i class="fa-solid fa-circle-info mr-1.5"></i>
                            Gunakan fitur ini jika menjual barang / jasa yang tidak terdaftar di stok katalog produk.
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 mb-1">Nama Item / Layanan <span class="text-rose-500">*</span></label>
                            <input type="text" id="customItemName" placeholder="Contoh: Jasa Pasang, Makanan Khusus" 
                                class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none">
                        </div>

                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Harga Satuan (Rp) <span class="text-rose-500">*</span></label>
                                <input type="number" id="customItemPrice" placeholder="0" min="0" 
                                    class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Jumlah (Qty)</label>
                                <input type="number" id="customItemQty" value="1" min="1" 
                                    class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none">
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 mb-1">Estimasi Biaya Modal / HPP (Opsional)</label>
                            <input type="number" id="customItemCost" placeholder="0" min="0" 
                                class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none">
                            <p class="text-[10px] text-slate-400 mt-1">Digunakan untuk menghitung laba bersih transaksi.</p>
                        </div>

                        <button type="button" onclick="addCustomItemToCart()" 
                            class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-sm transition-all flex items-center justify-center gap-2">
                            <i class="fa-solid fa-plus"></i>
                            <span>Tambahkan ke Keranjang</span>
                        </button>
                    </div>
                </div>

            </div>

            <!-- RIGHT: Keranjang & Pembayaran (40%) -->
            <div class="w-full lg:w-5/12 flex flex-col bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden h-[750px] lg:h-full">
                
                <form id="formCheckout" method="POST" action="kasir.php" class="flex flex-col h-full">
                    <input type="hidden" name="action" value="simpan_transaksi">
                    <input type="hidden" name="items_json" id="itemsJsonInput" value="[]">
                    <input type="hidden" name="print_receipt" id="printReceiptInput" value="0">

                    <!-- Cart Header -->
                    <div class="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                        <div>
                            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Nomor Invoice</span>
                            <div class="flex items-center gap-2">
                                <input type="text" name="nomor_transaksi" value="<?= $nomorAuto ?>" class="font-mono font-bold text-xs text-emerald-700 bg-transparent border-0 p-0 focus:ring-0 w-36">
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <a href="cetak-struk-rekap.php?periode=hari_ini" target="_blank" title="Cetak Struk Rekap Hari Ini" class="text-xs text-slate-500 hover:text-emerald-700 font-semibold flex items-center gap-1 transition-colors">
                                <i class="fa-solid fa-receipt text-emerald-600"></i>
                                <span>Struk Rekap Hari Ini</span>
                            </a>
                            <button type="button" onclick="clearCart()" class="text-xs text-rose-500 hover:text-rose-700 font-semibold flex items-center gap-1 transition-colors">
                                <i class="fa-regular fa-trash-can"></i>
                                <span>Kosongkan</span>
                            </button>
                        </div>
                    </div>

                    <!-- Customer & Date input -->
                    <div class="px-4 py-2.5 border-b border-slate-100 grid grid-cols-2 gap-2 bg-slate-50/20 text-xs">
                        <div>
                            <label class="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Nama Pelanggan</label>
                            <input type="text" name="nama_pelanggan" value="Pelanggan Umum" 
                                class="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:border-emerald-500">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Tanggal</label>
                            <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" 
                                class="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:border-emerald-500">
                        </div>
                    </div>

                    <!-- Cart Items List (Scrollable) -->
                    <div class="flex-1 overflow-y-auto p-4 space-y-2.5" id="cartItemsList">
                        <!-- Diisi secara dinamis via JavaScript -->
                    </div>

                    <!-- Empty Cart Placeholder -->
                    <div id="cartEmptyState" class="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-400">
                        <div class="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300 text-2xl mb-3">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </div>
                        <h4 class="font-semibold text-slate-600 text-sm">Keranjang Masih Kosong</h4>
                        <p class="text-xs text-slate-400 mt-1 max-w-xs">
                            Pilih produk di katalog sebelah kiri atau masukkan item kustom untuk mulai transaksi.
                        </p>
                    </div>

                    <!-- Payment & Totals Section -->
                    <div class="border-t border-slate-100 bg-slate-50/60 p-4 space-y-3">
                        
                        <!-- Subtotal & Diskon -->
                        <div class="space-y-1.5 text-xs text-slate-600">
                            <div class="flex justify-between items-center">
                                <span>Subtotal Belanja</span>
                                <span class="font-bold text-slate-800" id="subtotalText">Rp 0</span>
                            </div>
                            <div class="flex justify-between items-center gap-2">
                                <span class="text-slate-500">Diskon / Potongan</span>
                                <div class="flex items-center gap-1 w-32">
                                    <span class="text-slate-400 text-xs">Rp</span>
                                    <input type="number" id="inputDiskon" name="diskon" value="0" min="0" 
                                        class="w-full px-2 py-1 text-right text-xs bg-white border border-slate-200 rounded-lg font-semibold text-slate-700 focus:outline-none focus:border-emerald-500"
                                        oninput="calculateTotals()">
                                </div>
                            </div>
                            <div class="flex justify-between items-baseline pt-2 border-t border-slate-200/60">
                                <span class="font-bold text-sm text-slate-800">Total Akhir</span>
                                <span class="text-xl font-extrabold text-emerald-700 tracking-tight" id="totalAkhirText">Rp 0</span>
                            </div>
                        </div>

                        <!-- Metode Pembayaran -->
                        <div class="pt-2">
                            <label class="block text-[10px] font-bold uppercase text-slate-400 mb-1">Metode Pembayaran</label>
                            <div class="grid grid-cols-4 gap-1.5 text-xs font-semibold">
                                <label class="payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-emerald-500 bg-emerald-50 text-emerald-700 cursor-pointer transition-all">
                                    <input type="radio" name="metode_pembayaran" value="Tunai" checked class="hidden" onchange="updatePaymentUI()">
                                    <i class="fa-solid fa-money-bill-wave mb-1"></i>
                                    <span class="text-[10px]">Tunai</span>
                                </label>
                                <label class="payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-slate-200 bg-white text-slate-600 cursor-pointer hover:border-slate-300 transition-all">
                                    <input type="radio" name="metode_pembayaran" value="QRIS" class="hidden" onchange="updatePaymentUI()">
                                    <i class="fa-solid fa-qrcode mb-1"></i>
                                    <span class="text-[10px]">QRIS</span>
                                </label>
                                <label class="payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-slate-200 bg-white text-slate-600 cursor-pointer hover:border-slate-300 transition-all">
                                    <input type="radio" name="metode_pembayaran" value="Transfer Bank" class="hidden" onchange="updatePaymentUI()">
                                    <i class="fa-solid fa-building-columns mb-1"></i>
                                    <span class="text-[10px]">Transfer</span>
                                </label>
                                <label class="payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-slate-200 bg-white text-slate-600 cursor-pointer hover:border-slate-300 transition-all">
                                    <input type="radio" name="metode_pembayaran" value="Debit/Kredit" class="hidden" onchange="updatePaymentUI()">
                                    <i class="fa-solid fa-credit-card mb-1"></i>
                                    <span class="text-[10px]">Debit</span>
                                </label>
                            </div>
                        </div>

                        <!-- Bayar & Kembalian (Khusus Tunai) -->
                        <div id="tunaiFields" class="space-y-2 pt-1">
                            <div class="flex items-center gap-2">
                                <div class="flex-1">
                                    <label class="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Uang Diterima (Rp)</label>
                                    <input type="number" id="inputBayar" name="bayar" placeholder="0" min="0" 
                                        class="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500"
                                        oninput="calculateChange()">
                                </div>
                                <div class="w-36">
                                    <label class="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Kembalian</label>
                                    <div id="kembalianText" class="px-3 py-1.5 bg-slate-100 rounded-lg text-xs font-bold text-slate-700 truncate">
                                        Rp 0
                                    </div>
                                </div>
                            </div>

                            <!-- Tombol Nominal Cepat -->
                            <div class="flex items-center gap-1.5 overflow-x-auto text-[10px]">
                                <button type="button" onclick="setQuickBayar('pas')" class="px-2 py-1 bg-slate-200/80 hover:bg-slate-300 rounded text-slate-700 font-semibold whitespace-nowrap">Uang Pas</button>
                                <button type="button" onclick="setQuickBayar(50000)" class="px-2 py-1 bg-slate-200/80 hover:bg-slate-300 rounded text-slate-700 font-semibold whitespace-nowrap">50.000</button>
                                <button type="button" onclick="setQuickBayar(100000)" class="px-2 py-1 bg-slate-200/80 hover:bg-slate-300 rounded text-slate-700 font-semibold whitespace-nowrap">100.000</button>
                                <button type="button" onclick="setQuickBayar(200000)" class="px-2 py-1 bg-slate-200/80 hover:bg-slate-300 rounded text-slate-700 font-semibold whitespace-nowrap">200.000</button>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="pt-2 grid grid-cols-2 gap-2">
                            <button type="button" onclick="submitOrder(false)" id="btnSimpan" 
                                class="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm">
                                <i class="fa-solid fa-check"></i>
                                <span>Simpan Saja</span>
                            </button>
                            <button type="button" onclick="submitOrder(true)" id="btnSimpanCetak" 
                                class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 hover:scale-[1.01] active:scale-[0.98]">
                                <i class="fa-solid fa-print"></i>
                                <span>Simpan & Struk</span>
                            </button>
                        </div>

                    </div>
                </form>

            </div>

        </div>
    </main>

<script>
    // State Keranjang Belanja
    let cart = [];

    // Tab Switcher
    const tabKatalogBtn = document.getElementById('tabKatalogBtn');
    const tabCustomBtn = document.getElementById('tabCustomBtn');
    const viewKatalog = document.getElementById('viewKatalog');
    const viewCustom = document.getElementById('viewCustom');

    tabKatalogBtn.addEventListener('click', () => {
        tabKatalogBtn.className = "px-4 py-2 rounded-xl text-xs font-bold transition-all bg-emerald-600 text-white shadow-sm";
        tabCustomBtn.className = "px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-600 hover:bg-slate-200/70";
        viewKatalog.classList.remove('hidden');
        viewCustom.classList.add('hidden');
    });

    tabCustomBtn.addEventListener('click', () => {
        tabCustomBtn.className = "px-4 py-2 rounded-xl text-xs font-bold transition-all bg-emerald-600 text-white shadow-sm";
        tabKatalogBtn.className = "px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-600 hover:bg-slate-200/70";
        viewCustom.classList.remove('hidden');
        viewKatalog.classList.add('hidden');
    });

    // Filter Kategori
    document.querySelectorAll('.filter-cat').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-cat').forEach(b => {
                b.className = "filter-cat px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:bg-slate-100 transition-colors whitespace-nowrap";
            });
            btn.className = "filter-cat active px-3 py-1.5 rounded-lg font-semibold bg-emerald-100 text-emerald-800 transition-colors whitespace-nowrap";

            const catId = btn.getAttribute('data-cat');
            filterProducts();
        });
    });

    // Live Search Filter
    const searchInput = document.getElementById('searchProduct');
    searchInput.addEventListener('input', filterProducts);

    function filterProducts() {
        const query = searchInput.value.toLowerCase().trim();
        const activeCat = document.querySelector('.filter-cat.active')?.getAttribute('data-cat') || 'all';
        const cards = document.querySelectorAll('.product-card');
        let visibleCount = 0;

        cards.forEach(card => {
            const name = card.getAttribute('data-name').toLowerCase();
            const code = card.getAttribute('data-code').toLowerCase();
            const cat = card.getAttribute('data-cat');

            const matchQuery = !query || name.includes(query) || code.includes(query);
            const matchCat = activeCat === 'all' || cat === activeCat;

            if (matchQuery && matchCat) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });

        const noProd = document.getElementById('noProductFound');
        if (visibleCount === 0) {
            noProd.classList.remove('hidden');
        } else {
            noProd.classList.add('hidden');
        }
    }

    // Add to cart from Catalog Card
    function addToCartFromCard(el) {
        const id = el.getAttribute('data-id');
        const name = el.getAttribute('data-name');
        const price = parseFloat(el.getAttribute('data-price')) || 0;
        const cost = parseFloat(el.getAttribute('data-cost')) || 0;
        const stock = parseInt(el.getAttribute('data-stock'), 10) || 0;

        // Check if item already in cart
        const existing = cart.find(item => item.produk_id === id);
        if (existing) {
            if (stock > 0 && existing.qty >= stock) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Stok Terbatas',
                    text: `Maksimal stok tersedia untuk ${name} adalah ${stock}.`,
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            existing.qty += 1;
        } else {
            cart.push({
                produk_id: id,
                nama_item: name,
                harga_modal: cost,
                harga_satuan: price,
                qty: 1
            });
        }

        renderCart();
    }

    // Add Custom Item
    function addCustomItemToCart() {
        const name = document.getElementById('customItemName').value.trim();
        const price = parseFloat(document.getElementById('customItemPrice').value) || 0;
        const qty = parseInt(document.getElementById('customItemQty').value, 10) || 1;
        const cost = parseFloat(document.getElementById('customItemCost').value) || 0;

        if (!name) {
            Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Nama item harus diisi!' });
            return;
        }
        if (price <= 0) {
            Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Harga satuan harus lebih dari 0!' });
            return;
        }

        cart.push({
            produk_id: null,
            nama_item: name,
            harga_modal: cost,
            harga_satuan: price,
            qty: qty
        });

        // Reset form custom
        document.getElementById('customItemName').value = '';
        document.getElementById('customItemPrice').value = '';
        document.getElementById('customItemQty').value = '1';
        document.getElementById('customItemCost').value = '';

        // Pindah kembali ke katalog
        tabKatalogBtn.click();
        renderCart();
    }

    // Adjust Qty
    function updateQty(index, delta) {
        if (cart[index]) {
            cart[index].qty += delta;
            if (cart[index].qty <= 0) {
                cart.splice(index, 1);
            }
            renderCart();
        }
    }

    // Remove Item from Cart
    function removeCartItem(index) {
        cart.splice(index, 1);
        renderCart();
    }

    // Clear All Cart
    function clearCart() {
        if (cart.length === 0) return;
        cart = [];
        renderCart();
    }

    // Render Cart HTML
    function renderCart() {
        const listEl = document.getElementById('cartItemsList');
        const emptyEl = document.getElementById('cartEmptyState');

        if (cart.length === 0) {
            listEl.innerHTML = '';
            emptyEl.classList.remove('hidden');
        } else {
            emptyEl.classList.add('hidden');
            let html = '';

            cart.forEach((item, index) => {
                const subtotal = item.harga_satuan * item.qty;
                html += `
                    <div class="flex items-center justify-between p-2.5 rounded-xl border border-slate-200/80 bg-white hover:border-slate-300 transition-colors">
                        <div class="overflow-hidden pr-2 flex-1">
                            <h6 class="font-semibold text-slate-800 text-xs truncate leading-tight">${item.nama_item}</h6>
                            <span class="text-[11px] text-slate-400 font-medium">${formatRupiah(item.harga_satuan)}</span>
                        </div>

                        <!-- Qty Controls -->
                        <div class="flex items-center gap-1.5 mr-3">
                            <button type="button" onclick="updateQty(${index}, -1)" class="w-6 h-6 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold transition-colors">
                                -
                            </button>
                            <span class="w-7 text-center font-bold text-xs text-slate-800">${item.qty}</span>
                            <button type="button" onclick="updateQty(${index}, 1)" class="w-6 h-6 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold transition-colors">
                                +
                            </button>
                        </div>

                        <!-- Subtotal & Delete -->
                        <div class="text-right flex items-center gap-2">
                            <span class="font-bold text-xs text-slate-800 w-20 truncate">${formatRupiah(subtotal)}</span>
                            <button type="button" onclick="removeCartItem(${index})" class="text-slate-400 hover:text-rose-600 text-xs p-1">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                    </div>
                `;
            });

            listEl.innerHTML = html;
        }

        calculateTotals();
    }

    // Hitung Subtotal, Diskon, Total Akhir
    function calculateTotals() {
        let subtotal = 0;
        cart.forEach(item => {
            subtotal += (item.harga_satuan * item.qty);
        });

        const diskon = parseFloat(document.getElementById('inputDiskon').value) || 0;
        const totalAkhir = Math.max(0, subtotal - diskon);

        document.getElementById('subtotalText').innerText = formatRupiah(subtotal);
        document.getElementById('totalAkhirText').innerText = formatRupiah(totalAkhir);

        calculateChange();
    }

    // Hitung Kembalian
    function calculateChange() {
        let subtotal = 0;
        cart.forEach(item => {
            subtotal += (item.harga_satuan * item.qty);
        });
        const diskon = parseFloat(document.getElementById('inputDiskon').value) || 0;
        const totalAkhir = Math.max(0, subtotal - diskon);

        const bayar = parseFloat(document.getElementById('inputBayar').value) || 0;
        const kembalian = Math.max(0, bayar - totalAkhir);

        document.getElementById('kembalianText').innerText = formatRupiah(kembalian);
    }

    // Quick Bayar Buttons
    function setQuickBayar(val) {
        let subtotal = 0;
        cart.forEach(item => {
            subtotal += (item.harga_satuan * item.qty);
        });
        const diskon = parseFloat(document.getElementById('inputDiskon').value) || 0;
        const totalAkhir = Math.max(0, subtotal - diskon);

        if (val === 'pas') {
            document.getElementById('inputBayar').value = totalAkhir;
        } else {
            document.getElementById('inputBayar').value = val;
        }
        calculateChange();
    }

    // Update UI Metode Pembayaran
    function updatePaymentUI() {
        const radios = document.querySelectorAll('input[name="metode_pembayaran"]');
        let selected = 'Tunai';
        radios.forEach(r => {
            const card = r.closest('.payment-method-card');
            if (r.checked) {
                selected = r.value;
                card.className = "payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-emerald-500 bg-emerald-50 text-emerald-700 cursor-pointer transition-all";
            } else {
                card.className = "payment-method-card flex flex-col items-center justify-center p-2 rounded-xl border border-slate-200 bg-white text-slate-600 cursor-pointer hover:border-slate-300 transition-all";
            }
        });

        const tunaiBox = document.getElementById('tunaiFields');
        if (selected === 'Tunai') {
            tunaiBox.classList.remove('hidden');
        } else {
            tunaiBox.classList.add('hidden');
        }
    }

    // Submit Order
    function submitOrder(withPrint) {
        if (cart.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Keranjang Kosong',
                text: 'Silakan pilih produk terlebih dahulu sebelum menyimpan transaksi.'
            });
            return;
        }

        let subtotal = 0;
        cart.forEach(item => {
            subtotal += (item.harga_satuan * item.qty);
        });
        const diskon = parseFloat(document.getElementById('inputDiskon').value) || 0;
        const totalAkhir = Math.max(0, subtotal - diskon);

        const radios = document.querySelectorAll('input[name="metode_pembayaran"]');
        let selectedMetode = 'Tunai';
        radios.forEach(r => { if (r.checked) selectedMetode = r.value; });

        const bayar = parseFloat(document.getElementById('inputBayar').value) || 0;

        if (selectedMetode === 'Tunai' && bayar < totalAkhir) {
            Swal.fire({
                icon: 'warning',
                title: 'Pembayaran Kurang',
                text: `Total tagihan ${formatRupiah(totalAkhir)}, namun uang yang dimasukkan baru ${formatRupiah(bayar)}.`
            });
            return;
        }

        document.getElementById('itemsJsonInput').value = JSON.stringify(cart);
        document.getElementById('printReceiptInput').value = withPrint ? '1' : '0';

        document.getElementById('formCheckout').submit();
    }
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

